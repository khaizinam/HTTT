<?php
//
define('HOSTNAME', 'localhost');
define('USERTNAME', 'root');
define('PASS', '');
define('DATABASEBNAME', 'data_bhx');
?>